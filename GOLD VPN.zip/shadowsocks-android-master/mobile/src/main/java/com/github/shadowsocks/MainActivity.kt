/*******************************************************************************
 *                                                                             *
 *  Copyright (C) 2017 by Max Lv <max.c.lv@gmail.com>                          *
 *  Copyright (C) 2017 by Mygod Studio <contact-shadowsocks-android@mygod.be>  *
 *                                                                             *
 *  This program is free software: you can redistribute it and/or modify       *
 *  it under the terms of the GNU General Public License as published by       *
 *  the Free Software Foundation, either version 3 of the License, or          *
 *  (at your option) any later version.                                        *
 *                                                                             *
 *  This program is distributed in the hope that it will be useful,            *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 *  GNU General Public License for more details.                               *
 *                                                                             *
 *  You should have received a copy of the GNU General Public License          *
 *  along with this program. If not, see <http://www.gnu.org/licenses/>.       *
 *                                                                             *
 *******************************************************************************/
package com.github.shadowsocks

import android.os.Bundle
import android.os.RemoteException
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.preference.PreferenceDataStore
import com.github.shadowsocks.aidl.IShadowsocksService
import com.github.shadowsocks.aidl.ShadowsocksConnection
import com.github.shadowsocks.aidl.TrafficStats
import com.github.shadowsocks.bg.BaseService
import com.github.shadowsocks.preference.DataStore
import com.github.shadowsocks.preference.OnPreferenceDataStoreChangeListener
import com.github.shadowsocks.utils.Key
import com.github.shadowsocks.utils.StartService
import android.view.MenuItem
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), ShadowsocksConnection.Callback, OnPreferenceDataStoreChangeListener,
        NavigationView.OnNavigationItemSelectedListener {
    
    companion object {
        var stateListener: ((BaseService.State) -> Unit)? = null
    }

    var state = BaseService.State.Idle
    private val connection = ShadowsocksConnection(true)
    private val connect = registerForActivityResult(StartService()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.layout_main)

        val myWebView: WebView = findViewById(R.id.webview)
        myWebView.settings.javaScriptEnabled = true
        myWebView.settings.domStorageEnabled = true
        myWebView.webViewClient = WebViewClient()

        myWebView.addJavascriptInterface(object {
            @JavascriptInterface
            fun startVPN() {
                runOnUiThread { if (!state.canStop) connect.launch(null) }
            }
            @JavascriptInterface
            fun stopVPN() {
                runOnUiThread { if (state.canStop) Core.stopService() }
            }
        }, "AndroidBridge")

        myWebView.loadUrl("file:///android_asset/index.html")

        connection.connect(this, this)
        DataStore.publicStore.registerChangeListener(this)
    }

    override fun trafficUpdated(profileId: Long, stats: TrafficStats) { }
    override fun trafficPersisted(profileId: Long) { }
    override fun stateChanged(state: BaseService.State, profileName: String?, msg: String?) = changeState(state, msg)

    private fun changeState(state: BaseService.State, msg: String? = null, animate: Boolean = true) {
        this.state = state
        stateListener?.invoke(state)
    }

    override fun onServiceConnected(service: IShadowsocksService) = changeState(try {
        BaseService.State.entries[service.state]
    } catch (_: RemoteException) {
        BaseService.State.Idle
    })

    override fun onServiceDisconnected() = changeState(BaseService.State.Idle)
    override fun onBinderDied() {
        connection.disconnect(this)
        connection.connect(this, this)
    }

    override fun onPreferenceDataStoreChanged(store: PreferenceDataStore, key: String) {
        if (key == Key.serviceMode) {
            connection.disconnect(this)
            connection.connect(this, this)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean = true
    override fun onStart() { super.onStart(); connection.bandwidthTimeout = 500 }
    override fun onStop() { connection.bandwidthTimeout = 0; super.onStop() }
    override fun onDestroy() {
        super.onDestroy()
        DataStore.publicStore.unregisterChangeListener(this)
        connection.disconnect(this)
    }
}
